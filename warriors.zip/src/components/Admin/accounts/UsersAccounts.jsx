import { RingLoader } from "@/components/Loading";
import axios from "axios";
import Image from "next/image";

const { faSort, faPlus, faCircleUser } = require("@fortawesome/free-solid-svg-icons");
const { FontAwesomeIcon } = require("@fortawesome/react-fontawesome");
const { useState, useEffect } = require("react");

export default function UsersAccounts({ accounts }) {
  const [sending, setSending] = useState(false);

  async function addCategory(e) {
    e.preventDefault();

    if (sending) return;

    const data = {
      name: input.name,
      type,
    };

    setSending(true);
    try {
      const res = await axios.post("/api/categories/create", data);

      setCategories((prev) => [...prev, res.data]);
      setInput({ name: "" });
    } catch (err) {
      console.log(err);
    }
    setSending(false);
  }

  return (
    <section className=" max-w-[1000px] py-4 rounded-lg shadow-md ">
      <h2 className="font-medium text-xl text-slate-900 px-4">Users Accounts</h2>
      <div className="grid grid-cols-[1fr_100px_100px_100px_100px] bg-slate-100 mt-4 mb-2 px-4 border-y border-slate-200 font-medium text-sm">
        <div className=" py-3 text-slate-900">User</div>
        <div className=" py-3 text-slate-900">Likes</div>
        <div className=" py-3 text-slate-900">Member since</div>
        <div className=" py-3 text-slate-900">Friends</div>
        <div className=" py-3 text-slate-900">Remove</div>
      </div>
      {accounts?.map((user, index) => (
        <UserItem key={index} user={user} />
      ))}

      {!accounts?.length && (
        <div className="flex items-center px-4 py-3 font-medium text-slate-500">
          <p>There are no users</p>
        </div>
      )}
    </section>
  );
}

function UserItem({ user }) {
  const [sending, setSending] = useState(false);

  async function deleteCategory() {
    setSending(true);

    try {
      const res = await axios.delete("/api/categories/deleteById", {
        params: {
          id: user.id,
        },
      });

      setCategories((prev) => prev.filter((cat) => cat.id !== user.id));
    } catch (err) {
      console.log(err);
    }
    setSending(false);
  }

  return (
    <div key={user.id} className="grid grid-cols-[1fr_100px_100px_100px_100px] px-4 font-bold text-sm">
      <div className="flex items-center gap-3  py-2 text-slate-900 capitalize">
        <div className="flex gap-2 items-center">
          {user.picture ? (
            <div className="relative w-8 aspect-square rounded-full overflow-hidden">
              <Image src={`/uploads/profile-pictures/${user.picture}`} fill alt="Profile Image" className="object-cover" priority />
            </div>
          ) : (
            <FontAwesomeIcon icon={faCircleUser} className="text-3xl text-slate-500" />
          )}
          <p className="font-medium capitalize">{user.username || "Jon Doe"}</p>
        </div>
      </div>
      <div className="flex items-center gap-3  py-2 text-slate-900">
        <p suppressHydrationWarning>{user.likes || Math.floor(Math.random() * 1000)}</p>
      </div>
      <div className="flex items-center gap-3  py-2 text-slate-900">
        <p>{user.numbers || "123"}</p>
      </div>
      <div className="relative w-fit">
        <button
          onClick={() => {
            setShowDelete((prev) => (prev === user.id ? -1 : user.id));
          }}
          className="w-fit py-2 text-red-500"
        >
          Delete
        </button>
      </div>
      <div className=" py-2 text-purple-800">Update</div>
    </div>
  );
}
