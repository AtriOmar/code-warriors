import { faChevronDown } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useState } from "react";

export default function AllFAQ({ faqs }) {
  return (
    <div className="flex flex-col gap-4 max-w-[700px] mt-4">
      {faqs?.map((faq) => (
        <FAQItem key={faq.id} faq={faq} />
      ))}
    </div>
  );
}

function FAQItem({ faq }) {
  const [open, setOpen] = useState(false);

  return (
    <div className=" p-4 bg-white  border border-slate-300 shadow rounded-lg" suppressHydrationWarning>
      <button
        onClick={() => {
          setOpen((prev) => !prev);
        }}
        className="w-full flex justify-between items-center  rounded-lg text-lg font-medium capitalize"
      >
        {faq.title}
        <FontAwesomeIcon icon={faChevronDown} />
      </button>
      <div className={`${open ? "mt-3" : ""}`} style={{ transition: ".3s", gridTemplateRows: open ? "1fr" : "0fr", display: "grid" }}>
        <div className={` overflow-hidden text- text-slate-500`}>{faq.content}</div>
      </div>
    </div>
  );
}
