import AdminAccounts from "@/components/Admin/accounts/AdminAccounts";
import UsersAccounts from "@/components/Admin/accounts/UsersAccounts";
import { RingLoader } from "@/components/Loading";
import AdminLayout from "@/layouts/AdminLayout";
import axios from "axios";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import AllFAQ from "@/components/Admin/management/AllFAQ";

export default function FAQ({ faqs }) {
  return (
    <div className="">
      <AllFAQ faqs={faqs} />
      <AddFAQ />
    </div>
  );
}

function AddFAQ() {
  const [input, setInput] = useState({
    title: "",
    content: "",
  });
  const [sending, setSending] = useState(false);
  const router = useRouter();

  async function createFAQ() {
    if (sending) return;

    const data = {
      title: input.title,
      content: input.content,
    };

    setSending(true);
    try {
      const res = await axios.post("/api/faq/create", data);

      console.log(res.data);
    } catch (err) {
      console.log(err);
    }
    setSending(false);
  }

  return (
    <div>
      <h1 className="mt-4 font-bold">Title</h1>
      <input
        value={input.title}
        onChange={(e) => {
          setInput((prev) => ({ ...prev, title: e.target.value }));
        }}
        type="text"
        className="w-full mt-2 px-4 py-2 rounded-md border border-slate-300 outline-purple"
        placeholder="Title"
      />
      <h1 className="mt-2 font-bold">Content</h1>
      <textarea
        value={input.content}
        onChange={(e) => {
          setInput((prev) => ({ ...prev, content: e.target.value }));
        }}
        className="w-full mt-2 px-4 py-2 rounded-md border border-slate-300 outline-purple resize-none"
        rows={8}
        placeholder="Content"
      />
      <button
        onClick={createFAQ}
        className="relative block mt-8 ml-auto px-8 py-2 rounded-md bg-purple hover:bg-purple-700 text-white text-sm shadow-[1px_1px_7px_rgb(0,0,0,.2)] duration-300"
      >
        Add FAQ
        {sending ? (
          <i className="absolute right-1 top-1/2 -translate-y-1/2">
            <RingLoader color="white" />
          </i>
        ) : (
          ""
        )}
      </button>
    </div>
  );
}
