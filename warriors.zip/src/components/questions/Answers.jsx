import { formatDate } from "@/lib/formatDate";
import { faCircleUser } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import dynamic from "next/dynamic";
import Image from "next/image";
import Link from "next/link";

const Markdown = dynamic(
  () =>
    import("@uiw/react-md-editor").then((mod) => {
      return mod.default.Markdown;
    }),
  { ssr: false }
);

export default function Answers({ answers }) {
  return (
    <div className="px-4">
      <h2 className="mt-10 mb-2 font-bold text-xl">{answers.length} &nbsp; Answers</h2>
      {answers.map((answer) => (
        <Answer key={answer.id} answer={answer} />
      ))}
    </div>
  );
}

function Answer({ answer }) {
  const author = answer.User;

  return (
    <div className="mt-10">
      <Link href="/profile" className="flex gap-2 items-center">
        {author.picture ? (
          <div className="relative w-8 aspect-square rounded-full overflow-hidden">
            <Image src={`/uploads/profile-pictures/${author.picture}`} fill alt="Profile Image" className="object-cover" priority />
          </div>
        ) : (
          <FontAwesomeIcon icon={faCircleUser} className="text-3xl text-slate-500" />
        )}
        <p className="font-medium capitalize">{author.username}</p>
      </Link>
      <p className="mt-2 text-xs text-slate-700">Posted on {formatDate(new Date(answer.createdAt), "date")}</p>
      <div className="mt-4 px-2 pt-4 pb-8 border-b border-slate-300">
        <Markdown source={answer.content} />
      </div>
    </div>
  );
}
